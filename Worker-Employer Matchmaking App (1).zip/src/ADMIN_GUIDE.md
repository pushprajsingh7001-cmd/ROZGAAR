# ROZGAAR Admin Panel Guide

## Accessing the Admin Panel

### Quick Admin Login (Demo)

1. **Navigate to Login Screen**: From the welcome screen, click "Get Started"

2. **Use Admin Login Button**: At the bottom of the login screen, you'll see a "Login as Admin (Demo)" button. Click it.

3. **Complete Login**: 
   - The phone number field will auto-fill with `9999999999`
   - Make sure "Sign In" is selected (not Sign Up)
   - Enter any 4-digit OTP (e.g., `1234`)
   - Click "Sign In"

4. **Access Admin Dashboard**: You'll be automatically redirected to the Admin Dashboard

### Alternative: Manual Admin Account Creation

If you want to create an admin account manually:

1. Click "Sign Up" on the login screen
2. Enter phone: `9999999999`
3. Enter any name (e.g., "Admin")
4. Select any role (it will automatically be converted to Admin)
5. Complete signup

## Admin Panel Features

### Dashboard Overview

The Admin Dashboard displays:

- **Total Users**: Count of all registered users
- **Total Workers**: Number of worker accounts
- **Total Employers**: Number of employer accounts
- **Total Jobs**: All jobs posted on the platform
- **Job Statistics**: 
  - Open Jobs (available for application)
  - Assigned Jobs (worker selected but not completed)
  - Completed Jobs (finished)
- **Verified Workers**: Workers who have been verified by admin

### User Management

Click "User Management" to:

1. **View All Users**: See complete list of workers and employers
2. **Search Users**: Search by name or phone number
3. **Verify Workers**: Click "Verify" button to mark workers as verified (adds trust badge)
4. **Suspend/Activate Users**: 
   - Suspend problematic users
   - Reactivate suspended accounts
5. **View User Details**: 
   - Name, phone, role
   - Skills (for workers)
   - Verification status
   - Account status (Active/Suspended)

### Seed Demo Data

Click "Seed Demo Data" to automatically create:
- 3 demo worker accounts with different skills
- 2 demo employer accounts
- Located in Noida area with realistic profiles

This helps you test the platform functionality without manual data entry.

## Admin Capabilities

### What Admins Can Do:

✅ View all platform statistics
✅ Monitor all users (workers and employers)
✅ Verify worker accounts
✅ Suspend/activate user accounts
✅ Search and filter users
✅ Track job statistics (open, assigned, completed)
✅ See verified worker count and percentage

### What Admins Cannot Do (Current Implementation):

❌ Edit job details directly
❌ Delete users permanently
❌ View individual messages (no chat implemented)
❌ Handle payment disputes
❌ Send notifications to users

## Admin Workflow Examples

### Verifying a Worker

1. Go to User Management
2. Find the worker account
3. Review their details (skills, phone, etc.)
4. Click "Verify" button
5. Worker will now show verified badge to employers

### Handling User Issues

1. Go to User Management
2. Search for the problematic user
3. Click "Suspend" to temporarily disable their account
4. User cannot access platform while suspended
5. Click "Activate" later to restore access

### Monitoring Platform Health

1. Check Dashboard regularly
2. Monitor:
   - User growth (Total Users)
   - Job activity (Open/Assigned/Completed ratio)
   - Verification rate (Verified Workers %)
3. Use "Refresh Data" to get latest stats

## Technical Notes

- Admin role is automatically assigned to phone number `9999999999`
- Admin accounts bypass normal role selection
- Admin dashboard is separate from worker/employer interfaces
- All admin actions are logged (view server logs)
- Demo data uses phone numbers starting with `987654`

## Troubleshooting

**Can't access admin panel?**
- Ensure you used phone `9999999999`
- Check that you clicked "Sign In" not "Sign Up" (after first time)
- Clear browser cache and try again

**No users showing?**
- Click "Seed Demo Data" to create test users
- Check that backend server is running
- Refresh the page

**Stats not updating?**
- Click "Refresh Data" button
- Check browser console for errors
- Ensure API endpoints are accessible

## Security Notes

⚠️ **Important**: This is a demo implementation. For production:

- Implement proper admin authentication
- Add role-based access control (RBAC)
- Secure admin endpoints with proper authorization
- Add audit logging for all admin actions
- Implement admin approval workflow
- Add two-factor authentication for admin accounts
- Use environment variables for admin credentials
