import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Utility function to generate IDs
function generateId(prefix: string): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
}

// Calculate distance between two coordinates (Haversine formula)
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth's radius in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

// Health check endpoint
app.get("/make-server-e49dcc0e/health", (c) => {
  return c.json({ status: "ok" });
});

// ============ AUTH ROUTES ============

// Sign Up
app.post("/make-server-e49dcc0e/signup", async (c) => {
  try {
    const { phone, name, role, location, skills } = await c.req.json();

    if (!phone || !name || !role) {
      return c.json({ error: "Missing required fields" }, 400);
    }

    // Check if user already exists
    const existingUsers = await kv.getByPrefix("user:");
    const userExists = existingUsers.some((u: any) => u.phone === phone);
    
    if (userExists) {
      return c.json({ error: "User with this phone number already exists" }, 400);
    }

    const userId = generateId("user");
    
    // Special handling for admin account
    const isAdmin = phone === "9999999999";
    const userRole = isAdmin ? "Admin" : role;
    
    const user = {
      user_id: userId,
      phone,
      name,
      role: userRole,
      location: location || { lat: 28.6139, lng: 77.2090, address: "Delhi, India" },
      skills: skills || [],
      rating_avg: 0,
      rating_count: 0,
      status: "Active",
      verified: isAdmin ? true : false,
      available: role === "Worker" ? true : undefined,
      created_at: new Date().toISOString(),
    };

    await kv.set(`user:${userId}`, user);

    // Create mock session
    const session = {
      access_token: `token_${userId}`,
      user_id: userId,
    };

    return c.json({ user, session });
  } catch (error: any) {
    console.error("Signup error:", error);
    return c.json({ error: error.message || "Failed to sign up" }, 500);
  }
});

// Sign In
app.post("/make-server-e49dcc0e/signin", async (c) => {
  try {
    const { phone, otp } = await c.req.json();

    if (!phone) {
      return c.json({ error: "Phone number required" }, 400);
    }

    // For demo, accept any 4-digit OTP
    // In production, verify actual OTP

    const allUsers = await kv.getByPrefix("user:");
    const user = allUsers.find((u: any) => u.phone === phone);

    if (!user) {
      return c.json({ error: "User not found. Please sign up first." }, 404);
    }

    // Create mock session
    const session = {
      access_token: `token_${user.user_id}`,
      user_id: user.user_id,
    };

    return c.json({ user, session });
  } catch (error: any) {
    console.error("Signin error:", error);
    return c.json({ error: error.message || "Failed to sign in" }, 500);
  }
});

// ============ USER ROUTES ============

// Get User
app.get("/make-server-e49dcc0e/user/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const user = await kv.get(`user:${userId}`);

    if (!user) {
      return c.json({ error: "User not found" }, 404);
    }

    return c.json(user);
  } catch (error: any) {
    console.error("Get user error:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Update User
app.put("/make-server-e49dcc0e/user/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const updates = await c.req.json();

    const user = await kv.get(`user:${userId}`);
    if (!user) {
      return c.json({ error: "User not found" }, 404);
    }

    const updatedUser = { ...user, ...updates };
    await kv.set(`user:${userId}`, updatedUser);

    return c.json(updatedUser);
  } catch (error: any) {
    console.error("Update user error:", error);
    return c.json({ error: error.message }, 500);
  }
});

// ============ JOB ROUTES ============

// Post Job
app.post("/make-server-e49dcc0e/jobs", async (c) => {
  try {
    const jobData = await c.req.json();

    if (!jobData.employer_id || !jobData.job_title || !jobData.required_skill || !jobData.budget) {
      return c.json({ error: "Missing required fields" }, 400);
    }

    const jobId = generateId("job");
    const job = {
      job_id: jobId,
      employer_id: jobData.employer_id,
      job_title: jobData.job_title,
      description: jobData.description || "",
      required_skill: jobData.required_skill,
      budget: jobData.budget,
      job_location: jobData.job_location || { lat: 28.6139, lng: 77.2090, address: "Delhi, India" },
      date_posted: new Date().toISOString(),
      job_date: jobData.job_date || new Date().toISOString(),
      job_status: "Open",
      reported: false,
    };

    await kv.set(`job:${jobId}`, job);

    return c.json(job);
  } catch (error: any) {
    console.error("Post job error:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Get Jobs for Worker (nearby jobs matching skills)
app.get("/make-server-e49dcc0e/jobs/worker/:workerId", async (c) => {
  try {
    const workerId = c.req.param("workerId");
    const radius = parseFloat(c.req.query("radius") || "10");

    const worker = await kv.get(`user:${workerId}`);
    if (!worker) {
      return c.json({ error: "Worker not found" }, 404);
    }

    const allJobs = await kv.getByPrefix("job:");
    
    // Filter jobs: Open status, matching skills, within radius
    const workerSkills = worker.skills || [];
    const workerLat = worker.location?.lat || 28.6139;
    const workerLng = worker.location?.lng || 77.2090;

    const matchingJobs = allJobs
      .filter((job: any) => {
        if (job.job_status !== "Open") return false;
        if (!workerSkills.includes(job.required_skill)) return false;

        const jobLat = job.job_location?.lat || 28.6139;
        const jobLng = job.job_location?.lng || 77.2090;
        const distance = calculateDistance(workerLat, workerLng, jobLat, jobLng);

        return distance <= radius;
      })
      .map((job: any) => {
        const jobLat = job.job_location?.lat || 28.6139;
        const jobLng = job.job_location?.lng || 77.2090;
        const distance = calculateDistance(workerLat, workerLng, jobLat, jobLng);
        
        return {
          ...job,
          distance: Math.round(distance * 10) / 10, // Round to 1 decimal
        };
      })
      .sort((a: any, b: any) => a.distance - b.distance);

    return c.json(matchingJobs);
  } catch (error: any) {
    console.error("Get jobs for worker error:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Get Jobs for Employer
app.get("/make-server-e49dcc0e/jobs/employer/:employerId", async (c) => {
  try {
    const employerId = c.req.param("employerId");

    const allJobs = await kv.getByPrefix("job:");
    const employerJobs = allJobs
      .filter((job: any) => job.employer_id === employerId)
      .sort((a: any, b: any) => new Date(b.date_posted).getTime() - new Date(a.date_posted).getTime());

    return c.json(employerJobs);
  } catch (error: any) {
    console.error("Get jobs for employer error:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Get Single Job
app.get("/make-server-e49dcc0e/jobs/:jobId", async (c) => {
  try {
    const jobId = c.req.param("jobId");
    const job = await kv.get(`job:${jobId}`);

    if (!job) {
      return c.json({ error: "Job not found" }, 404);
    }

    return c.json(job);
  } catch (error: any) {
    console.error("Get job error:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Update Job
app.put("/make-server-e49dcc0e/jobs/:jobId", async (c) => {
  try {
    const jobId = c.req.param("jobId");
    const updates = await c.req.json();

    const job = await kv.get(`job:${jobId}`);
    if (!job) {
      return c.json({ error: "Job not found" }, 404);
    }

    const updatedJob = { ...job, ...updates };
    await kv.set(`job:${jobId}`, updatedJob);

    return c.json(updatedJob);
  } catch (error: any) {
    console.error("Update job error:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Delete Job
app.delete("/make-server-e49dcc0e/jobs/:jobId", async (c) => {
  try {
    const jobId = c.req.param("jobId");
    
    await kv.del(`job:${jobId}`);
    
    // Also delete related applications
    const allApps = await kv.getByPrefix("application:");
    const relatedApps = allApps.filter((app: any) => app.job_id === jobId);
    
    for (const app of relatedApps) {
      await kv.del(`application:${app.application_id}`);
    }

    return c.json({ success: true });
  } catch (error: any) {
    console.error("Delete job error:", error);
    return c.json({ error: error.message }, 500);
  }
});

// ============ APPLICATION ROUTES ============

// Apply for Job
app.post("/make-server-e49dcc0e/applications", async (c) => {
  try {
    const { job_id, worker_id } = await c.req.json();

    if (!job_id || !worker_id) {
      return c.json({ error: "Missing required fields" }, 400);
    }

    // Check if already applied
    const allApps = await kv.getByPrefix("application:");
    const existingApp = allApps.find(
      (app: any) => app.job_id === job_id && app.worker_id === worker_id
    );

    if (existingApp) {
      return c.json({ error: "Already applied to this job" }, 400);
    }

    const appId = generateId("app");
    const application = {
      application_id: appId,
      job_id,
      worker_id,
      status: "Pending",
      created_at: new Date().toISOString(),
    };

    await kv.set(`application:${appId}`, application);

    return c.json(application);
  } catch (error: any) {
    console.error("Apply for job error:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Get Applications for Job
app.get("/make-server-e49dcc0e/applications/job/:jobId", async (c) => {
  try {
    const jobId = c.req.param("jobId");

    const allApps = await kv.getByPrefix("application:");
    const jobApps = allApps.filter((app: any) => app.job_id === jobId);

    // Enrich with worker details
    const enrichedApps = await Promise.all(
      jobApps.map(async (app: any) => {
        const worker = await kv.get(`user:${app.worker_id}`);
        return {
          ...app,
          worker,
        };
      })
    );

    return c.json(enrichedApps);
  } catch (error: any) {
    console.error("Get applications for job error:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Get Applications for Worker
app.get("/make-server-e49dcc0e/applications/worker/:workerId", async (c) => {
  try {
    const workerId = c.req.param("workerId");

    const allApps = await kv.getByPrefix("application:");
    const workerApps = allApps.filter((app: any) => app.worker_id === workerId);

    // Enrich with job details
    const enrichedApps = await Promise.all(
      workerApps.map(async (app: any) => {
        const job = await kv.get(`job:${app.job_id}`);
        return {
          ...app,
          job,
        };
      })
    );

    return c.json(enrichedApps);
  } catch (error: any) {
    console.error("Get applications for worker error:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Update Application Status
app.put("/make-server-e49dcc0e/applications/:appId", async (c) => {
  try {
    const appId = c.req.param("appId");
    const { status, employer_id } = await c.req.json();

    const application = await kv.get(`application:${appId}`);
    if (!application) {
      return c.json({ error: "Application not found" }, 404);
    }

    const updatedApp = { ...application, status };
    await kv.set(`application:${appId}`, updatedApp);

    // If accepted, update job status to Assigned
    if (status === "Accepted") {
      const job = await kv.get(`job:${application.job_id}`);
      if (job) {
        const updatedJob = { ...job, job_status: "Assigned", assigned_worker_id: application.worker_id };
        await kv.set(`job:${application.job_id}`, updatedJob);
      }

      // Reject other applications for this job
      const allApps = await kv.getByPrefix("application:");
      const otherApps = allApps.filter(
        (app: any) => app.job_id === application.job_id && app.application_id !== appId
      );

      for (const app of otherApps) {
        if (app.status === "Pending") {
          await kv.set(`application:${app.application_id}`, { ...app, status: "Rejected" });
        }
      }
    }

    return c.json(updatedApp);
  } catch (error: any) {
    console.error("Update application error:", error);
    return c.json({ error: error.message }, 500);
  }
});

// ============ RATING ROUTES ============

// Submit Rating
app.post("/make-server-e49dcc0e/ratings", async (c) => {
  try {
    const { job_id, from_user_id, to_user_id, rating, review } = await c.req.json();

    if (!job_id || !from_user_id || !to_user_id || rating === undefined) {
      return c.json({ error: "Missing required fields" }, 400);
    }

    const ratingId = generateId("rating");
    const ratingData = {
      rating_id: ratingId,
      job_id,
      from_user_id,
      to_user_id,
      rating,
      review: review || "",
      created_at: new Date().toISOString(),
    };

    await kv.set(`rating:${ratingId}`, ratingData);

    // Update user's average rating
    const allRatings = await kv.getByPrefix("rating:");
    const userRatings = allRatings.filter((r: any) => r.to_user_id === to_user_id);
    const avgRating = userRatings.reduce((sum: number, r: any) => sum + r.rating, 0) / userRatings.length;

    const user = await kv.get(`user:${to_user_id}`);
    if (user) {
      const updatedUser = {
        ...user,
        rating_avg: Math.round(avgRating * 10) / 10,
        rating_count: userRatings.length,
      };
      await kv.set(`user:${to_user_id}`, updatedUser);
    }

    return c.json(ratingData);
  } catch (error: any) {
    console.error("Submit rating error:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Get Ratings for User
app.get("/make-server-e49dcc0e/ratings/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");

    const allRatings = await kv.getByPrefix("rating:");
    const userRatings = allRatings.filter((r: any) => r.to_user_id === userId);

    // Enrich with from_user details
    const enrichedRatings = await Promise.all(
      userRatings.map(async (rating: any) => {
        const fromUser = await kv.get(`user:${rating.from_user_id}`);
        return {
          ...rating,
          from_user: fromUser,
        };
      })
    );

    return c.json(enrichedRatings);
  } catch (error: any) {
    console.error("Get ratings error:", error);
    return c.json({ error: error.message }, 500);
  }
});

// ============ ADMIN ROUTES ============

// Get All Users
app.get("/make-server-e49dcc0e/admin/users", async (c) => {
  try {
    const allUsers = await kv.getByPrefix("user:");
    return c.json(allUsers);
  } catch (error: any) {
    console.error("Get all users error:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Get All Jobs
app.get("/make-server-e49dcc0e/admin/jobs", async (c) => {
  try {
    const allJobs = await kv.getByPrefix("job:");
    return c.json(allJobs);
  } catch (error: any) {
    console.error("Get all jobs error:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Get Admin Stats
app.get("/make-server-e49dcc0e/admin/stats", async (c) => {
  try {
    const allUsers = await kv.getByPrefix("user:");
    const allJobs = await kv.getByPrefix("job:");

    const stats = {
      total_users: allUsers.length,
      total_workers: allUsers.filter((u: any) => u.role === "Worker").length,
      total_employers: allUsers.filter((u: any) => u.role === "Employer").length,
      total_jobs: allJobs.length,
      open_jobs: allJobs.filter((j: any) => j.job_status === "Open").length,
      assigned_jobs: allJobs.filter((j: any) => j.job_status === "Assigned").length,
      completed_jobs: allJobs.filter((j: any) => j.job_status === "Completed").length,
      verified_workers: allUsers.filter((u: any) => u.role === "Worker" && u.verified).length,
    };

    return c.json(stats);
  } catch (error: any) {
    console.error("Get admin stats error:", error);
    return c.json({ error: error.message }, 500);
  }
});

// Update User Status (Admin)
app.put("/make-server-e49dcc0e/admin/users/:userId", async (c) => {
  try {
    const userId = c.req.param("userId");
    const updates = await c.req.json();

    const user = await kv.get(`user:${userId}`);
    if (!user) {
      return c.json({ error: "User not found" }, 404);
    }

    const updatedUser = { ...user, ...updates };
    await kv.set(`user:${userId}`, updatedUser);

    return c.json(updatedUser);
  } catch (error: any) {
    console.error("Update user status error:", error);
    return c.json({ error: error.message }, 500);
  }
});

Deno.serve(app.fetch);
