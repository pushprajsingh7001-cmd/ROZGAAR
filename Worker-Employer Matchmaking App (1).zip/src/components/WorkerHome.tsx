import { useState, useEffect } from 'react';
import { MapPin, Briefcase, IndianRupee } from 'lucide-react';
import { api } from '../utils/api';
import { t } from '../utils/translations';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { toast } from 'sonner@2.0.3';

type WorkerHomeProps = {
  user: any;
  language: 'en' | 'hi';
  onViewJob: (jobId: string) => void;
  onUpdateUser: (updates: any) => void;
};

export function WorkerHome({ user, language, onViewJob, onUpdateUser }: WorkerHomeProps) {
  const [jobs, setJobs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [available, setAvailable] = useState(user.available || false);
  const [appliedJobs, setAppliedJobs] = useState<Set<string>>(new Set());

  useEffect(() => {
    loadJobs();
    loadApplications();
  }, [user.user_id]);

  const loadJobs = async () => {
    setLoading(true);
    try {
      const data = await api.getJobsForWorker(user.user_id);
      if (!data.error) {
        setJobs(data);
      }
    } catch (error) {
      console.error('Error loading jobs:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadApplications = async () => {
    try {
      const data = await api.getApplicationsForWorker(user.user_id);
      if (!data.error) {
        const jobIds = new Set(data.map((app: any) => app.job_id));
        setAppliedJobs(jobIds);
      }
    } catch (error) {
      console.error('Error loading applications:', error);
    }
  };

  const handleToggleAvailability = async () => {
    const newAvailable = !available;
    setAvailable(newAvailable);
    
    try {
      await api.updateUser(user.user_id, { available: newAvailable });
      onUpdateUser({ available: newAvailable });
      toast.success(newAvailable ? 'You are now available for work' : 'You are now unavailable');
    } catch (error) {
      console.error('Error updating availability:', error);
      setAvailable(!newAvailable);
    }
  };

  const handleApply = async (jobId: string) => {
    try {
      const result = await api.applyForJob(jobId, user.user_id);
      if (result.error) {
        toast.error(result.error);
      } else {
        setAppliedJobs(new Set([...appliedJobs, jobId]));
        toast.success('Application submitted successfully!');
      }
    } catch (error) {
      console.error('Error applying for job:', error);
      toast.error('Failed to apply for job');
    }
  };

  return (
    <div className="pb-20">
      {/* Header */}
      <div className="bg-blue-600 text-white p-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1>{user.name}</h1>
            <div className="flex items-center gap-1 text-white/80 mt-1">
              <MapPin className="w-4 h-4" />
              <span className="text-sm">{user.location.address}</span>
            </div>
          </div>
        </div>

        {/* Availability Toggle */}
        <Card className="p-4 bg-white/10 backdrop-blur-sm border-white/20">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-white">
                {available ? t('availableForWork', language) : t('notAvailable', language)}
              </Label>
              <p className="text-xs text-white/70 mt-1">
                {available ? 'You will receive job notifications' : 'Turn on to find work'}
              </p>
            </div>
            <Switch 
              checked={available} 
              onCheckedChange={handleToggleAvailability}
              className="data-[state=checked]:bg-green-500"
            />
          </div>
        </Card>
      </div>

      {/* Jobs Feed */}
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h2>{t('nearbyJobs', language)}</h2>
          <Button variant="outline" size="sm" onClick={loadJobs}>
            Refresh
          </Button>
        </div>

        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <Card key={i} className="p-4 animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </Card>
            ))}
          </div>
        ) : jobs.length === 0 ? (
          <Card className="p-8 text-center">
            <Briefcase className="w-12 h-12 mx-auto text-gray-400 mb-3" />
            <p className="text-gray-600">{t('noJobsFound', language)}</p>
            <p className="text-sm text-gray-500 mt-2">
              Jobs matching your skills will appear here
            </p>
          </Card>
        ) : (
          <div className="space-y-3">
            {jobs.map(job => (
              <Card 
                key={job.job_id} 
                className="p-4 cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => onViewJob(job.job_id)}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h3 className="mb-1">{job.job_title}</h3>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Badge variant="secondary">{t(job.required_skill, language)}</Badge>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {job.distance} {t('km', language)} {t('away', language)}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 text-green-600">
                    <IndianRupee className="w-4 h-4" />
                    <span>{job.budget}</span>
                  </div>
                </div>

                <p className="text-sm text-gray-600 mb-3 line-clamp-2">{job.description}</p>

                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-500">
                    {new Date(job.date_posted).toLocaleDateString()}
                  </span>
                  {appliedJobs.has(job.job_id) ? (
                    <Badge variant="default">{t('applied', language)}</Badge>
                  ) : (
                    <Button 
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleApply(job.job_id);
                      }}
                    >
                      {t('apply', language)}
                    </Button>
                  )}
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
