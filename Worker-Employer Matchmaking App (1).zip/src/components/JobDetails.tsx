import { useState, useEffect } from 'react';
import { ArrowLeft, MapPin, IndianRupee, Calendar, User, Star, Phone } from 'lucide-react';
import { api } from '../utils/api';
import { t } from '../utils/translations';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { toast } from 'sonner@2.0.3';

type JobDetailsProps = {
  jobId: string;
  user: any;
  language: 'en' | 'hi';
  onBack: () => void;
  onViewProfile: (userId: string) => void;
};

export function JobDetails({ jobId, user, language, onBack, onViewProfile }: JobDetailsProps) {
  const [job, setJob] = useState<any>(null);
  const [applications, setApplications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [hasApplied, setHasApplied] = useState(false);
  const [showRatingDialog, setShowRatingDialog] = useState(false);
  const [rating, setRating] = useState(0);
  const [review, setReview] = useState('');
  const [ratingFor, setRatingFor] = useState<any>(null);

  useEffect(() => {
    loadJobDetails();
  }, [jobId]);

  const loadJobDetails = async () => {
    setLoading(true);
    try {
      const jobData = await api.getJob(jobId);
      if (!jobData.error) {
        setJob(jobData);

        // Load applications if employer
        if (user.role === 'Employer' && jobData.employer_id === user.user_id) {
          const appsData = await api.getApplicationsForJob(jobId);
          if (!appsData.error) {
            setApplications(appsData);
          }
        }

        // Check if worker has applied
        if (user.role === 'Worker') {
          const workerApps = await api.getApplicationsForWorker(user.user_id);
          if (!workerApps.error) {
            const applied = workerApps.some((app: any) => app.job_id === jobId);
            setHasApplied(applied);
          }
        }
      }
    } catch (error) {
      console.error('Error loading job details:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApply = async () => {
    try {
      const result = await api.applyForJob(jobId, user.user_id);
      if (result.error) {
        toast.error(result.error);
      } else {
        setHasApplied(true);
        toast.success('Application submitted successfully!');
      }
    } catch (error) {
      console.error('Error applying for job:', error);
      toast.error('Failed to apply for job');
    }
  };

  const handleAcceptWorker = async (appId: string) => {
    try {
      const result = await api.updateApplication(appId, 'Accepted', user.user_id);
      if (result.error) {
        toast.error(result.error);
      } else {
        toast.success('Worker accepted!');
        loadJobDetails();
      }
    } catch (error) {
      console.error('Error accepting worker:', error);
      toast.error('Failed to accept worker');
    }
  };

  const handleRejectWorker = async (appId: string) => {
    try {
      const result = await api.updateApplication(appId, 'Rejected', user.user_id);
      if (result.error) {
        toast.error(result.error);
      } else {
        toast.success('Application rejected');
        loadJobDetails();
      }
    } catch (error) {
      console.error('Error rejecting worker:', error);
      toast.error('Failed to reject worker');
    }
  };

  const handleMarkCompleted = async () => {
    try {
      const result = await api.updateJob(jobId, { job_status: 'Completed' });
      if (result.error) {
        toast.error(result.error);
      } else {
        toast.success('Job marked as completed!');
        loadJobDetails();
        
        // Prompt to rate worker
        if (job.assigned_worker_id) {
          const worker = await api.getUser(job.assigned_worker_id);
          if (!worker.error) {
            setRatingFor(worker);
            setShowRatingDialog(true);
          }
        }
      }
    } catch (error) {
      console.error('Error marking job completed:', error);
      toast.error('Failed to mark job as completed');
    }
  };

  const handleSubmitRating = async () => {
    if (rating === 0) {
      toast.error('Please select a rating');
      return;
    }

    try {
      const result = await api.submitRating({
        job_id: jobId,
        from_user_id: user.user_id,
        to_user_id: ratingFor.user_id,
        rating,
        review
      });

      if (result.error) {
        toast.error(result.error);
      } else {
        toast.success('Rating submitted!');
        setShowRatingDialog(false);
        setRating(0);
        setReview('');
      }
    } catch (error) {
      console.error('Error submitting rating:', error);
      toast.error('Failed to submit rating');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <Card className="p-8 animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-3/4 mb-4"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2"></div>
        </Card>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <Card className="p-8 text-center">
          <p>Job not found</p>
          <Button className="mt-4" onClick={onBack}>Go Back</Button>
        </Card>
      </div>
    );
  }

  const isEmployerView = user.role === 'Employer' && job.employer_id === user.user_id;
  const isWorkerView = user.role === 'Worker';

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="bg-blue-600 text-white p-4">
        <Button
          variant="ghost"
          onClick={onBack}
          className="text-white hover:bg-white/10 mb-2"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          {t('back', language)}
        </Button>
        <h1>{t('jobDetails', language)}</h1>
      </div>

      <div className="p-4 space-y-4">
        {/* Job Info */}
        <Card className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <h2 className="mb-2">{job.job_title}</h2>
              <Badge variant="secondary">{t(job.required_skill, language)}</Badge>
            </div>
            <Badge variant={job.job_status === 'Open' ? 'default' : 'outline'}>
              {t(job.job_status.toLowerCase(), language)}
            </Badge>
          </div>

          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <IndianRupee className="w-5 h-5 text-green-600 mt-0.5" />
              <div>
                <div className="text-sm text-gray-600">{t('budget', language)}</div>
                <div className="text-xl text-green-600">₹{job.budget}</div>
              </div>
            </div>

            <Separator />

            <div className="flex items-start gap-3">
              <MapPin className="w-5 h-5 text-gray-600 mt-0.5" />
              <div>
                <div className="text-sm text-gray-600">{t('location', language)}</div>
                <div>{job.job_location.address}</div>
              </div>
            </div>

            <Separator />

            <div className="flex items-start gap-3">
              <Calendar className="w-5 h-5 text-gray-600 mt-0.5" />
              <div>
                <div className="text-sm text-gray-600">{t('postedOn', language)}</div>
                <div>{new Date(job.date_posted).toLocaleDateString()}</div>
              </div>
            </div>

            <Separator />

            <div>
              <div className="text-sm text-gray-600 mb-2">{t('description', language)}</div>
              <p>{job.description}</p>
            </div>
          </div>

          {/* Actions for Worker */}
          {isWorkerView && job.job_status === 'Open' && (
            <div className="mt-6">
              {hasApplied ? (
                <Badge variant="default" className="w-full justify-center py-2">
                  {t('applied', language)}
                </Badge>
              ) : (
                <Button className="w-full" onClick={handleApply}>
                  {t('apply', language)}
                </Button>
              )}
            </div>
          )}

          {/* Actions for Employer */}
          {isEmployerView && job.job_status === 'Assigned' && (
            <div className="mt-6">
              <Button className="w-full" onClick={handleMarkCompleted}>
                {t('markCompleted', language)}
              </Button>
            </div>
          )}
        </Card>

        {/* Applications - For Employer */}
        {isEmployerView && (
          <Card className="p-6">
            <h3 className="mb-4">
              {t('applications', language)} ({applications.length})
            </h3>

            {applications.length === 0 ? (
              <p className="text-gray-500 text-center py-4">{t('noApplications', language)}</p>
            ) : (
              <div className="space-y-3">
                {applications.map(app => (
                  <Card key={app.application_id} className="p-4">
                    <div className="flex items-start justify-between">
                      <div 
                        className="flex items-start gap-3 flex-1 cursor-pointer"
                        onClick={() => onViewProfile(app.worker.user_id)}
                      >
                        <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                          <User className="w-6 h-6 text-blue-600" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h4>{app.worker.name}</h4>
                            {app.worker.is_verified && (
                              <Badge variant="secondary" className="text-xs">
                                {t('verified', language)}
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-2 text-sm text-gray-600 mt-1">
                            {app.worker.rating_avg > 0 && (
                              <div className="flex items-center gap-1">
                                <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                                <span>{app.worker.rating_avg}</span>
                              </div>
                            )}
                            <span>•</span>
                            <span>{app.worker.skills.map((s: string) => t(s, language)).join(', ')}</span>
                          </div>
                          <Badge variant="outline" className="mt-2">
                            {t(app.status.toLowerCase(), language)}
                          </Badge>
                        </div>
                      </div>

                      {app.status === 'Pending' && job.job_status === 'Open' && (
                        <div className="flex gap-2 ml-2">
                          <Button 
                            size="sm" 
                            onClick={() => handleAcceptWorker(app.application_id)}
                          >
                            {t('acceptWorker', language)}
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handleRejectWorker(app.application_id)}
                          >
                            {t('rejectWorker', language)}
                          </Button>
                        </div>
                      )}
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </Card>
        )}
      </div>

      {/* Rating Dialog */}
      <Dialog open={showRatingDialog} onOpenChange={setShowRatingDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {user.role === 'Employer' ? t('rateWorker', language) : t('rateEmployer', language)}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            {ratingFor && (
              <div className="text-center">
                <p className="text-sm text-gray-600 mb-2">Rating for</p>
                <p>{ratingFor.name}</p>
              </div>
            )}

            <div>
              <Label>{t('rating', language)} *</Label>
              <div className="flex gap-2 justify-center mt-2">
                {[1, 2, 3, 4, 5].map(star => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    className="focus:outline-none"
                  >
                    <Star
                      className={`w-8 h-8 ${
                        star <= rating 
                          ? 'fill-yellow-400 text-yellow-400' 
                          : 'text-gray-300'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>

            <div>
              <Label>{t('writeReview', language)}</Label>
              <Textarea
                value={review}
                onChange={(e) => setReview(e.target.value)}
                rows={3}
                placeholder="Share your experience..."
              />
            </div>

            <Button className="w-full" onClick={handleSubmitRating}>
              {t('submitRating', language)}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
