import { useState, useEffect } from 'react';
import { Users, Briefcase, CheckCircle, TrendingUp, UserCheck, FileText, LogOut, Database } from 'lucide-react';
import { api } from '../utils/api';
import { seedDemoData } from '../utils/seedData';
import { t } from '../utils/translations';
import { toast } from 'sonner@2.0.3';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';

type AdminDashboardProps = {
  language: 'en' | 'hi';
  onViewUsers: () => void;
  onLogout: () => void;
};

export function AdminDashboard({ language, onViewUsers, onLogout }: AdminDashboardProps) {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    setLoading(true);
    try {
      const data = await api.getAdminStats();
      if (!data.error) {
        setStats(data);
      }
    } catch (error) {
      console.error('Error loading stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSeedData = async () => {
    setLoading(true);
    toast.info('Creating demo data...');
    const success = await seedDemoData();
    if (success) {
      toast.success('Demo data created successfully!');
      loadStats();
    } else {
      toast.error('Failed to create demo data');
    }
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="p-4">
        <div className="grid grid-cols-2 gap-3">
          {[1, 2, 3, 4].map(i => (
            <Card key={i} className="p-4 animate-pulse">
              <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
              <div className="h-6 bg-gray-200 rounded w-3/4"></div>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-4">
        <h1 className="mb-1">{t('adminDashboard', language)}</h1>
        <p className="text-sm text-white/80">Monitor and manage platform activity</p>
      </div>

      <div className="p-4 space-y-4">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3">
          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <Users className="w-5 h-5 text-blue-600" />
              </div>
              <div className="flex-1">
                <div className="text-sm text-gray-600">{t('totalUsers', language)}</div>
                <div className="text-2xl">{stats?.total_users || 0}</div>
              </div>
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <Briefcase className="w-5 h-5 text-green-600" />
              </div>
              <div className="flex-1">
                <div className="text-sm text-gray-600">{t('totalJobs', language)}</div>
                <div className="text-2xl">{stats?.total_jobs || 0}</div>
              </div>
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <UserCheck className="w-5 h-5 text-purple-600" />
              </div>
              <div className="flex-1">
                <div className="text-sm text-gray-600">{t('totalWorkers', language)}</div>
                <div className="text-2xl">{stats?.total_workers || 0}</div>
              </div>
            </div>
          </Card>

          <Card className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-orange-600" />
              </div>
              <div className="flex-1">
                <div className="text-sm text-gray-600">{t('totalEmployers', language)}</div>
                <div className="text-2xl">{stats?.total_employers || 0}</div>
              </div>
            </div>
          </Card>
        </div>

        {/* Job Stats */}
        <Card className="p-4">
          <h3 className="mb-3">Job Statistics</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-sm">{t('openJobs', language)}</span>
              </div>
              <Badge variant="outline">{stats?.open_jobs || 0}</Badge>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <span className="text-sm">{t('assignedJobs', language)}</span>
              </div>
              <Badge variant="outline">{stats?.assigned_jobs || 0}</Badge>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-gray-500 rounded-full"></div>
                <span className="text-sm">{t('completedJobs', language)}</span>
              </div>
              <Badge variant="outline">{stats?.completed_jobs || 0}</Badge>
            </div>
          </div>
        </Card>

        {/* Verified Workers */}
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <div>
                <div className="text-sm text-gray-600">{t('verifiedWorkers', language)}</div>
                <div className="text-xl">{stats?.verified_workers || 0}</div>
              </div>
            </div>
            <div className="text-sm text-gray-600">
              {stats?.total_workers > 0 
                ? `${Math.round((stats.verified_workers / stats.total_workers) * 100)}%`
                : '0%'}
            </div>
          </div>
        </Card>

        {/* Action Buttons */}
        <div className="space-y-3">
          <Button onClick={onViewUsers} className="w-full h-auto py-4 flex items-center gap-3">
            <Users className="w-6 h-6" />
            <span>{t('userManagement', language)}</span>
          </Button>
          
          <Button variant="outline" className="w-full" onClick={loadStats}>
            Refresh Data
          </Button>

          <Button 
            variant="outline" 
            className="w-full border-green-300 text-green-600 hover:bg-green-50" 
            onClick={handleSeedData}
            disabled={loading}
          >
            <Database className="w-4 h-4 mr-2" />
            Seed Demo Data
          </Button>

          <Button variant="outline" className="w-full text-red-600 hover:text-red-700" onClick={onLogout}>
            <LogOut className="w-4 h-4 mr-2" />
            {t('logout', language)}
          </Button>
        </div>
      </div>
    </div>
  );
}
