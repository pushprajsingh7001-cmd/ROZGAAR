import { useState, useEffect } from "react";
import { Briefcase, MapPin, IndianRupee } from "lucide-react";
import { api } from "../utils/api";
import { t } from "../utils/translations";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";

type MyApplicationsProps = {
  user: any;
  language: "en" | "hi";
  onViewJob: (jobId: string) => void;
};

export function MyApplications({
  user,
  language,
  onViewJob,
}: MyApplicationsProps) {
  const [applications, setApplications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadApplications();
  }, [user.user_id]);

  const loadApplications = async () => {
    setLoading(true);
    try {
      const data = await api.getApplicationsForWorker(
        user.user_id,
      );
      if (!data.error) {
        setApplications(data);
      }
    } catch (error) {
      console.error("Error loading applications:", error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: any = {
      Pending: "default",
      Accepted: "secondary",
      Rejected: "outline",
    };
    return (
      <Badge variant={variants[status] || "default"}>
        {t(status.toLowerCase(), language)}
      </Badge>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="bg-blue-600 text-white p-4">
        <h1>{t("myApplications", language)}</h1>
      </div>

      <div className="p-4">
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="p-4 animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </Card>
            ))}
          </div>
        ) : applications.length === 0 ? (
          <Card className="p-8 text-center">
            <Briefcase className="w-12 h-12 mx-auto text-gray-400 mb-3" />
            <p className="text-gray-600">
              {t("noApplications", language)}
            </p>
          </Card>
        ) : (
          <div className="space-y-3">
            {applications.map(
              (app) =>
                app.job && (
                  <Card
                    key={app.application_id}
                    className="p-4 cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => onViewJob(app.job_id)}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <h3 className="mb-1">
                          {app.job.job_title}
                        </h3>
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Badge variant="secondary">
                            {t(
                              app.job.required_skill,
                              language,
                            )}
                          </Badge>
                          {getStatusBadge(app.status)}
                        </div>
                      </div>
                      <div className="flex items-center gap-1 text-green-600">
                        <IndianRupee className="w-4 h-4" />
                        <span>{app.job.budget}</span>
                      </div>
                    </div>

                    <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                      {app.job.description}
                    </p>

                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        <span>
                          {app.job.job_location.address}
                        </span>
                      </div>
                      <span>
                        {new Date(
                          app.applied_at,
                        ).toLocaleDateString()}
                      </span>
                    </div>
                  </Card>
                ),
            )}
          </div>
        )}
      </div>
    </div>
  );
}