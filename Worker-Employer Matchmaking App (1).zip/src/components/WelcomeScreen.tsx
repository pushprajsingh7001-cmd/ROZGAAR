import { Briefcase, Globe } from 'lucide-react';
import { Language } from '../App';
import { t } from '../utils/translations';
import { Button } from './ui/button';

type WelcomeScreenProps = {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  onStart: () => void;
};

export function WelcomeScreen({ language, onLanguageChange, onStart }: WelcomeScreenProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 to-blue-800 flex flex-col items-center justify-center p-4">
      <div className="absolute top-4 right-4">
        <Button
          variant="outline"
          size="sm"
          onClick={() => onLanguageChange(language === 'en' ? 'hi' : 'en')}
          className="bg-white/10 text-white border-white/20 hover:bg-white/20"
        >
          <Globe className="w-4 h-4 mr-2" />
          {language === 'en' ? 'हिंदी' : 'English'}
        </Button>
      </div>

      <div className="text-center space-y-8 max-w-md">
        <div className="bg-white/10 backdrop-blur-sm rounded-full p-6 inline-block">
          <Briefcase className="w-20 h-20 text-white" />
        </div>

        <div>
          <p className="text-white/90 text-xl mb-2">{t('welcome', language)}</p>
          <h1 className="text-white text-6xl mb-4">{t('appName', language)}</h1>
          <p className="text-white/80 text-lg">{t('tagline', language)}</p>
        </div>

        <Button
          onClick={onStart}
          size="lg"
          className="bg-white text-blue-600 hover:bg-gray-100 px-12 py-6 text-xl"
        >
          {t('start', language)}
        </Button>

        <div className="text-white/60 text-sm mt-8 space-y-2">
          <p>Connecting daily wage workers with local employers</p>
          <p>Rural & Semi-Urban Focus • Lightweight • Multilingual</p>
          <div className="mt-4 pt-4 border-t border-white/20">
            <p className="text-xs text-white/40">
              💡 Admin Panel: Use "Login as Admin" button on next screen
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
