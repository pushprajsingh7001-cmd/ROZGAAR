import { useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { api } from '../utils/api';
import { t } from '../utils/translations';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { toast } from 'sonner@2.0.3';

const SKILLS = [
  'mason', 'plumber', 'electrician', 'carpenter', 'painter',
  'farmLabor', 'domesticHelper', 'driver', 'gardener', 'generalLabor'
];

type PostJobFormProps = {
  user: any;
  language: 'en' | 'hi';
  onBack: () => void;
  onSuccess: () => void;
};

export function PostJobForm({ user, language, onBack, onSuccess }: PostJobFormProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [skill, setSkill] = useState('');
  const [budget, setBudget] = useState('');
  const [location, setLocation] = useState(user.location.address);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!title || !description || !skill || !budget) {
      toast.error('Please fill all required fields');
      return;
    }

    setLoading(true);

    try {
      const jobData = {
        employer_id: user.user_id,
        job_title: title,
        description,
        required_skill: skill,
        budget: parseFloat(budget),
        job_location: {
          lat: user.location.lat + (Math.random() - 0.5) * 0.01,
          lng: user.location.lng + (Math.random() - 0.5) * 0.01,
          address: location
        },
        job_date: new Date().toISOString(),
      };

      const result = await api.postJob(jobData);

      if (result.error) {
        toast.error(result.error);
      } else {
        toast.success('Job posted successfully!');
        onSuccess();
      }
    } catch (error: any) {
      console.error('Error posting job:', error);
      toast.error('Failed to post job');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="bg-blue-600 text-white p-4">
        <Button
          variant="ghost"
          onClick={onBack}
          className="text-white hover:bg-white/10 mb-2"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          {t('back', language)}
        </Button>
        <h1>{t('postNewJob', language)}</h1>
      </div>

      <div className="p-4">
        <Card className="p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label>{t('jobTitle', language)} *</Label>
              <Input
                placeholder={t('enterJobTitle', language)}
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>

            <div>
              <Label>{t('jobDescription', language)} *</Label>
              <Textarea
                placeholder={t('enterJobDescription', language)}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={4}
                required
              />
            </div>

            <div>
              <Label>{t('selectSkill', language)} *</Label>
              <Select value={skill} onValueChange={setSkill}>
                <SelectTrigger>
                  <SelectValue placeholder={t('selectSkill', language)} />
                </SelectTrigger>
                <SelectContent>
                  {SKILLS.map(s => (
                    <SelectItem key={s} value={s}>
                      {t(s, language)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>{t('jobBudget', language)} *</Label>
              <Input
                type="number"
                placeholder={t('enterBudget', language)}
                value={budget}
                onChange={(e) => setBudget(e.target.value)}
                required
              />
            </div>

            <div>
              <Label>{t('jobLocation', language)}</Label>
              <Input
                placeholder={t('enterLocation', language)}
                value={location}
                onChange={(e) => setLocation(e.target.value)}
              />
            </div>

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? 'Posting...' : t('postJobButton', language)}
            </Button>
          </form>
        </Card>
      </div>
    </div>
  );
}
