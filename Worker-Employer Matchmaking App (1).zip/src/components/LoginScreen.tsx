import { useState } from 'react';
import { ArrowLeft, Briefcase, Building2 } from 'lucide-react';
import { Language, User } from '../App';
import { t } from '../utils/translations';
import { api } from '../utils/api';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card } from './ui/card';

type LoginScreenProps = {
  language: Language;
  onLogin: (user: User, token: string) => void;
  onBack: () => void;
};

const SKILLS = [
  'mason', 'plumber', 'electrician', 'carpenter', 'painter',
  'farmLabor', 'domesticHelper', 'driver', 'gardener', 'generalLabor'
];

export function LoginScreen({ language, onLogin, onBack }: LoginScreenProps) {
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<'Worker' | 'Employer' | null>(null);
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  const [isNewUser, setIsNewUser] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Quick Admin Login Helper
  const handleAdminLogin = () => {
    setPhone('9999999999');
    setName('Admin');
    setIsNewUser(false);
  };

  const toggleSkill = (skill: string) => {
    if (selectedSkills.includes(skill)) {
      setSelectedSkills(selectedSkills.filter(s => s !== skill));
    } else {
      setSelectedSkills([...selectedSkills, skill]);
    }
  };

  const handleSignUp = async () => {
    if (!phone || !name || !role) {
      setError('Please fill all required fields');
      return;
    }

    if (role === 'Worker' && selectedSkills.length === 0) {
      setError('Please select at least one skill');
      return;
    }

    setLoading(true);
    setError('');

    try {
      // Get user's location (mock for demo)
      const location = {
        lat: 28.6139 + (Math.random() - 0.5) * 0.1,
        lng: 77.2090 + (Math.random() - 0.5) * 0.1,
        address: 'Demo Location, India'
      };

      const result = await api.signup({
        phone,
        name,
        role,
        location,
        skills: role === 'Worker' ? selectedSkills : []
      });

      if (result.error) {
        setError(result.error);
      } else {
        onLogin(result.user, result.session.access_token);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to sign up');
    } finally {
      setLoading(false);
    }
  };

  const handleSignIn = async () => {
    if (!phone) {
      setError('Please enter phone number');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const result = await api.signin(phone, otp);

      if (result.error) {
        setError(result.error);
      } else {
        onLogin(result.user, result.session.access_token);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to sign in');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 to-blue-800 p-4">
      <div className="max-w-lg mx-auto pt-8">
        <Button
          variant="ghost"
          onClick={onBack}
          className="text-white hover:bg-white/10 mb-4"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          {t('back', language)}
        </Button>

        <Card className="p-6">
          <h2 className="text-center mb-6">{t('login', language)}</h2>

          <div className="space-y-4">
            <div>
              <Label>{t('phoneNumber', language)}</Label>
              <Input
                type="tel"
                placeholder={t('enterPhone', language)}
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                maxLength={10}
              />
            </div>

            <div className="flex gap-2">
              <Button
                variant={isNewUser ? 'default' : 'outline'}
                onClick={() => setIsNewUser(true)}
                className="flex-1"
              >
                {t('signUp', language)}
              </Button>
              <Button
                variant={!isNewUser ? 'default' : 'outline'}
                onClick={() => setIsNewUser(false)}
                className="flex-1"
              >
                {t('signIn', language)}
              </Button>
            </div>

            {!isNewUser && (
              <div>
                <Label>{t('otp', language)}</Label>
                <Input
                  type="text"
                  placeholder={t('enterOTP', language)}
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                  maxLength={4}
                />
              </div>
            )}

            {isNewUser && (
              <>
                <div>
                  <Label>{t('yourName', language)}</Label>
                  <Input
                    type="text"
                    placeholder={t('enterName', language)}
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>

                <div>
                  <Label>{t('selectRole', language)}</Label>
                  <div className="grid grid-cols-2 gap-3 mt-2">
                    <Button
                      type="button"
                      variant={role === 'Worker' ? 'default' : 'outline'}
                      onClick={() => setRole('Worker')}
                      className="h-auto py-4 flex flex-col gap-2"
                    >
                      <Briefcase className="w-6 h-6" />
                      <span>{t('worker', language)}</span>
                    </Button>
                    <Button
                      type="button"
                      variant={role === 'Employer' ? 'default' : 'outline'}
                      onClick={() => setRole('Employer')}
                      className="h-auto py-4 flex flex-col gap-2"
                    >
                      <Building2 className="w-6 h-6" />
                      <span>{t('employer', language)}</span>
                    </Button>
                  </div>
                </div>

                {role === 'Worker' && (
                  <div>
                    <Label>{t('skills', language)}</Label>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {SKILLS.map(skill => (
                        <Button
                          key={skill}
                          type="button"
                          size="sm"
                          variant={selectedSkills.includes(skill) ? 'default' : 'outline'}
                          onClick={() => toggleSkill(skill)}
                        >
                          {t(skill, language)}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}

            {error && (
              <p className="text-red-600 text-sm">{error}</p>
            )}

            <Button
              onClick={isNewUser ? handleSignUp : handleSignIn}
              disabled={loading}
              className="w-full"
            >
              {loading ? '...' : isNewUser ? t('signUp', language) : t('signIn', language)}
            </Button>

            {/* Quick Admin Access - Demo Only */}
            <div className="pt-4 border-t">
              <p className="text-xs text-gray-500 text-center mb-2">Demo Admin Access</p>
              <Button
                type="button"
                variant="outline"
                onClick={handleAdminLogin}
                className="w-full text-purple-600 border-purple-300"
              >
                Login as Admin (Demo)
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
