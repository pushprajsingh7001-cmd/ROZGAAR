import { useState, useEffect } from 'react';
import { ArrowLeft, User, Search, CheckCircle, Ban, UserCheck } from 'lucide-react';
import { api } from '../utils/api';
import { t } from '../utils/translations';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { toast } from 'sonner@2.0.3';

type AdminUsersProps = {
  language: 'en' | 'hi';
  onBack: () => void;
};

export function AdminUsers({ language, onBack }: AdminUsersProps) {
  const [users, setUsers] = useState<any[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadUsers();
  }, []);

  useEffect(() => {
    if (searchTerm) {
      const filtered = users.filter(user => 
        user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.phone.includes(searchTerm)
      );
      setFilteredUsers(filtered);
    } else {
      setFilteredUsers(users);
    }
  }, [searchTerm, users]);

  const loadUsers = async () => {
    setLoading(true);
    try {
      const data = await api.getAllUsers();
      if (!data.error) {
        setUsers(data);
        setFilteredUsers(data);
      }
    } catch (error) {
      console.error('Error loading users:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyUser = async (userId: string) => {
    try {
      const result = await api.updateUserStatus(userId, { verified: true });
      if (result.error) {
        toast.error(result.error);
      } else {
        toast.success('User verified successfully');
        loadUsers();
      }
    } catch (error) {
      console.error('Error verifying user:', error);
      toast.error('Failed to verify user');
    }
  };

  const handleSuspendUser = async (userId: string, currentStatus: string) => {
    const newStatus = currentStatus === 'Active' ? 'Suspended' : 'Active';
    try {
      const result = await api.updateUserStatus(userId, { status: newStatus });
      if (result.error) {
        toast.error(result.error);
      } else {
        toast.success(`User ${newStatus.toLowerCase()} successfully`);
        loadUsers();
      }
    } catch (error) {
      console.error('Error updating user status:', error);
      toast.error('Failed to update user status');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="bg-purple-600 text-white p-4">
        <Button
          variant="ghost"
          onClick={onBack}
          className="text-white hover:bg-white/10 mb-2"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          {t('back', language)}
        </Button>
        <h1>{t('userManagement', language)}</h1>
        <p className="text-sm text-white/80 mt-1">
          {t('allUsers', language)}: {users.length}
        </p>
      </div>

      <div className="p-4 space-y-4">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder={t('search', language)}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Users List */}
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3, 4].map(i => (
              <Card key={i} className="p-4 animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </Card>
            ))}
          </div>
        ) : filteredUsers.length === 0 ? (
          <Card className="p-8 text-center">
            <User className="w-12 h-12 mx-auto text-gray-400 mb-3" />
            <p className="text-gray-600">No users found</p>
          </Card>
        ) : (
          <div className="space-y-3">
            {filteredUsers.map(user => (
              <Card key={user.user_id} className="p-4">
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <User className="w-6 h-6 text-blue-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="truncate">{user.name}</h3>
                      {user.verified && (
                        <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
                      )}
                    </div>
                    <p className="text-sm text-gray-600">{user.phone}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant={user.role === 'Worker' ? 'default' : 'secondary'}>
                        {t(user.role.toLowerCase(), language)}
                      </Badge>
                      <Badge variant={user.status === 'Active' ? 'outline' : 'destructive'}>
                        {t(user.status.toLowerCase(), language)}
                      </Badge>
                    </div>
                    {user.role === 'Worker' && user.skills.length > 0 && (
                      <p className="text-xs text-gray-500 mt-2">
                        {user.skills.map((s: string) => t(s, language)).join(', ')}
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex gap-2 mt-4">
                  {user.role === 'Worker' && !user.verified && (
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => handleVerifyUser(user.user_id)}
                      className="flex-1"
                    >
                      <UserCheck className="w-3 h-3 mr-1" />
                      {t('verify', language)}
                    </Button>
                  )}
                  <Button 
                    size="sm" 
                    variant={user.status === 'Active' ? 'destructive' : 'default'}
                    onClick={() => handleSuspendUser(user.user_id, user.status)}
                    className="flex-1"
                  >
                    <Ban className="w-3 h-3 mr-1" />
                    {user.status === 'Active' ? t('suspend', language) : t('activate', language)}
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
