import { useState, useEffect } from 'react';
import { ArrowLeft, User, Star, MapPin, Briefcase, CheckCircle } from 'lucide-react';
import { api } from '../utils/api';
import { t } from '../utils/translations';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';

type UserProfileProps = {
  userId: string;
  currentUser: any;
  language: 'en' | 'hi';
  onBack: () => void;
};

export function UserProfile({ userId, currentUser, language, onBack }: UserProfileProps) {
  const [user, setUser] = useState<any>(null);
  const [ratings, setRatings] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadUserProfile();
  }, [userId]);

  const loadUserProfile = async () => {
    setLoading(true);
    try {
      const userData = await api.getUser(userId);
      if (!userData.error) {
        setUser(userData);
      }

      const ratingsData = await api.getRatings(userId);
      if (!ratingsData.error) {
        setRatings(ratingsData);
      }
    } catch (error) {
      console.error('Error loading user profile:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <Card className="p-8 animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-3/4 mb-4"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2"></div>
        </Card>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <Card className="p-8 text-center">
          <p>User not found</p>
          <Button className="mt-4" onClick={onBack}>Go Back</Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="bg-blue-600 text-white p-4">
        <Button
          variant="ghost"
          onClick={onBack}
          className="text-white hover:bg-white/10 mb-2"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          {t('back', language)}
        </Button>
        <h1>{t('profile', language)}</h1>
      </div>

      <div className="p-4 space-y-4">
        {/* User Info */}
        <Card className="p-6">
          <div className="flex items-start gap-4 mb-4">
            <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center">
              <User className="w-10 h-10 text-blue-600" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <h2>{user.name}</h2>
                {user.is_verified && (
                  <CheckCircle className="w-5 h-5 text-green-600" />
                )}
              </div>
              <Badge variant="secondary">
                {t(user.role.toLowerCase(), language)}
              </Badge>
              {user.is_verified && (
                <Badge variant="outline" className="ml-2">
                  {t('verified', language)}
                </Badge>
              )}
              <div className="flex items-center gap-1 text-gray-600 mt-2">
                <MapPin className="w-4 h-4" />
                <span className="text-sm">{user.location.address}</span>
              </div>
            </div>
          </div>

          {user.rating_count > 0 && (
            <>
              <Separator className="my-4" />
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-gray-600">{t('ratings', language)}</div>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex items-center gap-1">
                      <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                      <span className="text-xl">{user.rating_avg}</span>
                    </div>
                    <span className="text-sm text-gray-600">({user.rating_count} {t('reviews', language)})</span>
                  </div>
                </div>
              </div>
            </>
          )}

          {user.role === 'Worker' && user.skills.length > 0 && (
            <>
              <Separator className="my-4" />
              <div>
                <div className="text-sm text-gray-600 mb-2">{t('skills', language)}</div>
                <div className="flex flex-wrap gap-2">
                  {user.skills.map((skill: string) => (
                    <Badge key={skill} variant="outline">
                      <Briefcase className="w-3 h-3 mr-1" />
                      {t(skill, language)}
                    </Badge>
                  ))}
                </div>
              </div>
            </>
          )}
        </Card>

        {/* Reviews */}
        {ratings.length > 0 && (
          <Card className="p-6">
            <h3 className="mb-4">{t('reviews', language)}</h3>
            <div className="space-y-4">
              {ratings.map(rating => (
                <div key={rating.rating_id}>
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                      <User className="w-5 h-5 text-gray-600" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <span>{rating.from_user?.name || 'Anonymous'}</span>
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                          <span>{rating.rating}</span>
                        </div>
                      </div>
                      {rating.review && (
                        <p className="text-sm text-gray-600">{rating.review}</p>
                      )}
                      <p className="text-xs text-gray-400 mt-1">
                        {new Date(rating.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  {ratings.indexOf(rating) < ratings.length - 1 && (
                    <Separator className="my-3" />
                  )}
                </div>
              ))}
            </div>
          </Card>
        )}

        {ratings.length === 0 && user.rating_count === 0 && (
          <Card className="p-8 text-center">
            <Star className="w-12 h-12 mx-auto text-gray-400 mb-3" />
            <p className="text-gray-600">{t('noReviews', language)}</p>
          </Card>
        )}
      </div>
    </div>
  );
}
