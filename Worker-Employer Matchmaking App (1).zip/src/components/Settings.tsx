import { Globe, HelpCircle, FileText, LogOut } from 'lucide-react';
import { t } from '../utils/translations';
import { Button } from './ui/button';
import { Card } from './ui/card';

type SettingsProps = {
  language: 'en' | 'hi';
  onLanguageChange: (lang: 'en' | 'hi') => void;
  onLogout: () => void;
};

export function Settings({ language, onLanguageChange, onLogout }: SettingsProps) {
  // Get user from localStorage
  const user = JSON.parse(localStorage.getItem('rozgaar_user') || '{}');
  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="bg-blue-600 text-white p-4">
        <h1>{t('settings', language)}</h1>
      </div>

      <div className="p-4 space-y-3">
        {/* User Info */}
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <h3>{user.name}</h3>
              <p className="text-sm text-gray-600">{user.phone}</p>
              <p className="text-xs text-gray-500 mt-1">{t(user.role.toLowerCase(), language)}</p>
            </div>
          </div>
        </Card>

        {/* Language */}
        <Card className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <Globe className="w-5 h-5 text-gray-600" />
              <div>
                <div>{t('language', language)}</div>
                <div className="text-sm text-gray-600">
                  {language === 'en' ? t('english', language) : t('hindi', language)}
                </div>
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            <Button
              variant={language === 'en' ? 'default' : 'outline'}
              size="sm"
              onClick={() => onLanguageChange('en')}
              className="flex-1"
            >
              English
            </Button>
            <Button
              variant={language === 'hi' ? 'default' : 'outline'}
              size="sm"
              onClick={() => onLanguageChange('hi')}
              className="flex-1"
            >
              हिंदी
            </Button>
          </div>
        </Card>

        {/* Help & Support */}
        <Card className="p-4">
          <button className="w-full flex items-center gap-3 text-left">
            <HelpCircle className="w-5 h-5 text-gray-600" />
            <div className="flex-1">
              <div>{t('helpSupport', language)}</div>
              <div className="text-sm text-gray-600">Get help and support</div>
            </div>
          </button>
        </Card>

        {/* Privacy Policy */}
        <Card className="p-4">
          <button className="w-full flex items-center gap-3 text-left">
            <FileText className="w-5 h-5 text-gray-600" />
            <div className="flex-1">
              <div>{t('privacyPolicy', language)}</div>
              <div className="text-sm text-gray-600">Read our privacy policy</div>
            </div>
          </button>
        </Card>

        {/* Logout */}
        <Card className="p-4">
          <button 
            className="w-full flex items-center gap-3 text-left text-red-600"
            onClick={onLogout}
          >
            <LogOut className="w-5 h-5" />
            <div className="flex-1">
              <div>{t('logout', language)}</div>
              <div className="text-sm text-red-500">Sign out of your account</div>
            </div>
          </button>
        </Card>

        {/* App Info */}
        <div className="text-center text-sm text-gray-500 pt-4">
          <p>ROZGAAR v1.0</p>
          <p className="mt-1">Connecting Workers & Employers</p>
        </div>
      </div>
    </div>
  );
}
