import { useState, useEffect } from 'react';
import { Plus, Briefcase, Users, MapPin, IndianRupee } from 'lucide-react';
import { api } from '../utils/api';
import { t } from '../utils/translations';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';

type EmployerHomeProps = {
  user: any;
  language: 'en' | 'hi';
  onPostJob: () => void;
  onViewJob: (jobId: string) => void;
};

export function EmployerHome({ user, language, onPostJob, onViewJob }: EmployerHomeProps) {
  const [jobs, setJobs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadJobs();
  }, [user.user_id]);

  const loadJobs = async () => {
    setLoading(true);
    try {
      const data = await api.getJobsForEmployer(user.user_id);
      if (!data.error) {
        setJobs(data);
      }
    } catch (error) {
      console.error('Error loading jobs:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: any = {
      'Open': 'default',
      'Assigned': 'secondary',
      'Completed': 'outline'
    };
    return (
      <Badge variant={variants[status] || 'default'}>
        {t(status.toLowerCase(), language)}
      </Badge>
    );
  };

  return (
    <div className="pb-20">
      {/* Header */}
      <div className="bg-blue-600 text-white p-4">
        <div className="flex items-center justify-between mb-2">
          <div>
            <h1>{user.name}</h1>
            <div className="flex items-center gap-1 text-white/80 mt-1">
              <MapPin className="w-4 h-4" />
              <span className="text-sm">{user.location.address}</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2 mt-4">
          <Card className="p-3 bg-white/10 backdrop-blur-sm border-white/20 text-center">
            <div className="text-2xl">{jobs.filter(j => j.job_status === 'Open').length}</div>
            <div className="text-xs text-white/70 mt-1">{t('open', language)}</div>
          </Card>
          <Card className="p-3 bg-white/10 backdrop-blur-sm border-white/20 text-center">
            <div className="text-2xl">{jobs.filter(j => j.job_status === 'Assigned').length}</div>
            <div className="text-xs text-white/70 mt-1">{t('assigned', language)}</div>
          </Card>
          <Card className="p-3 bg-white/10 backdrop-blur-sm border-white/20 text-center">
            <div className="text-2xl">{jobs.filter(j => j.job_status === 'Completed').length}</div>
            <div className="text-xs text-white/70 mt-1">{t('completed', language)}</div>
          </Card>
        </div>
      </div>

      {/* Jobs List */}
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h2>{t('myJobs', language)}</h2>
          <Button variant="outline" size="sm" onClick={loadJobs}>
            Refresh
          </Button>
        </div>

        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <Card key={i} className="p-4 animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </Card>
            ))}
          </div>
        ) : jobs.length === 0 ? (
          <Card className="p-8 text-center">
            <Briefcase className="w-12 h-12 mx-auto text-gray-400 mb-3" />
            <p className="text-gray-600">{t('noJobsPosted', language)}</p>
            <Button className="mt-4" onClick={onPostJob}>
              <Plus className="w-4 h-4 mr-2" />
              {t('postJob', language)}
            </Button>
          </Card>
        ) : (
          <div className="space-y-3">
            {jobs.map(job => (
              <Card 
                key={job.job_id}
                className="p-4 cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => onViewJob(job.job_id)}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h3 className="mb-1">{job.job_title}</h3>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Badge variant="secondary">{t(job.required_skill, language)}</Badge>
                      {getStatusBadge(job.job_status)}
                    </div>
                  </div>
                  <div className="flex items-center gap-1 text-green-600">
                    <IndianRupee className="w-4 h-4" />
                    <span>{job.budget}</span>
                  </div>
                </div>

                <p className="text-sm text-gray-600 mb-3 line-clamp-2">{job.description}</p>

                <div className="flex items-center justify-between text-xs text-gray-500">
                  <span>{new Date(job.date_posted).toLocaleDateString()}</span>
                  {job.job_status === 'Open' && (
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        onViewJob(job.job_id);
                      }}
                    >
                      <Users className="w-3 h-3 mr-1" />
                      {t('viewApplications', language)}
                    </Button>
                  )}
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Floating Action Button */}
      <Button
        size="lg"
        className="fixed bottom-20 right-4 rounded-full w-14 h-14 shadow-lg"
        onClick={onPostJob}
      >
        <Plus className="w-6 h-6" />
      </Button>
    </div>
  );
}
