import { useState, useEffect } from 'react';
import { Home, User, FileText, Settings as SettingsIcon, Briefcase } from 'lucide-react';
import { WelcomeScreen } from './components/WelcomeScreen';
import { LoginScreen } from './components/LoginScreen';
import { WorkerHome } from './components/WorkerHome';
import { EmployerHome } from './components/EmployerHome';
import { JobDetails } from './components/JobDetails';
import { PostJobForm } from './components/PostJobForm';
import { MyApplications } from './components/MyApplications';
import { UserProfile } from './components/UserProfile';
import { Settings } from './components/Settings';
import { AdminDashboard } from './components/AdminDashboard';
import { AdminUsers } from './components/AdminUsers';
import { Toaster } from './components/ui/sonner';

export type Language = 'en' | 'hi';

export type User = {
  user_id: string;
  phone: string;
  name: string;
  role: 'Worker' | 'Employer' | 'Admin';
  location: {
    lat: number;
    lng: number;
    address: string;
  };
  skills?: string[];
  rating_avg: number;
  rating_count: number;
  status: string;
  verified: boolean;
  available?: boolean;
};

type Screen = 
  | 'welcome'
  | 'login'
  | 'home'
  | 'jobDetails'
  | 'postJob'
  | 'myApplications'
  | 'profile'
  | 'settings'
  | 'adminDashboard'
  | 'adminUsers';

export default function App() {
  const [language, setLanguage] = useState<Language>('en');
  const [currentScreen, setCurrentScreen] = useState<Screen>('welcome');
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string>('');
  const [selectedJobId, setSelectedJobId] = useState<string>('');
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  const [bottomTab, setBottomTab] = useState<'home' | 'applications' | 'profile' | 'settings'>('home');

  // Load user from localStorage on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('rozgaar_user');
    const savedToken = localStorage.getItem('rozgaar_token');
    const savedLanguage = localStorage.getItem('rozgaar_language');

    if (savedUser && savedToken) {
      setUser(JSON.parse(savedUser));
      setToken(savedToken);
      setCurrentScreen('home');
    }

    if (savedLanguage) {
      setLanguage(savedLanguage as Language);
    }
  }, []);

  const handleLogin = (loggedInUser: User, userToken: string) => {
    setUser(loggedInUser);
    setToken(userToken);
    localStorage.setItem('rozgaar_user', JSON.stringify(loggedInUser));
    localStorage.setItem('rozgaar_token', userToken);
    
    if (loggedInUser.role === 'Admin') {
      setCurrentScreen('adminDashboard');
    } else {
      setCurrentScreen('home');
    }
  };

  const handleLogout = () => {
    setUser(null);
    setToken('');
    localStorage.removeItem('rozgaar_user');
    localStorage.removeItem('rozgaar_token');
    setCurrentScreen('welcome');
  };

  const handleLanguageChange = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('rozgaar_language', lang);
  };

  const handleUpdateUser = (updates: any) => {
    if (user) {
      const updatedUser = { ...user, ...updates };
      setUser(updatedUser);
      localStorage.setItem('rozgaar_user', JSON.stringify(updatedUser));
    }
  };

  const handleViewJob = (jobId: string) => {
    setSelectedJobId(jobId);
    setCurrentScreen('jobDetails');
  };

  const handleViewProfile = (userId: string) => {
    setSelectedUserId(userId);
    setCurrentScreen('profile');
  };

  const handleBottomTabChange = (tab: 'home' | 'applications' | 'profile' | 'settings') => {
    setBottomTab(tab);
    
    if (tab === 'home') {
      setCurrentScreen('home');
    } else if (tab === 'applications') {
      setCurrentScreen('myApplications');
    } else if (tab === 'profile') {
      setSelectedUserId(user?.user_id || '');
      setCurrentScreen('profile');
    } else if (tab === 'settings') {
      setCurrentScreen('settings');
    }
  };

  const renderBottomNav = () => {
    if (!user || currentScreen === 'adminDashboard' || currentScreen === 'adminUsers') {
      return null;
    }

    if (currentScreen === 'welcome' || currentScreen === 'login') {
      return null;
    }

    const tabs = user.role === 'Worker' 
      ? [
          { id: 'home', icon: Home, label: 'Home' },
          { id: 'applications', icon: FileText, label: 'Applications' },
          { id: 'profile', icon: User, label: 'Profile' },
          { id: 'settings', icon: SettingsIcon, label: 'Settings' },
        ]
      : [
          { id: 'home', icon: Briefcase, label: 'Jobs' },
          { id: 'profile', icon: User, label: 'Profile' },
          { id: 'settings', icon: SettingsIcon, label: 'Settings' },
        ];

    return (
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2 flex justify-around items-center z-50">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = bottomTab === tab.id;
          
          return (
            <button
              key={tab.id}
              onClick={() => handleBottomTabChange(tab.id as any)}
              className={`flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-colors ${
                isActive ? 'text-blue-600' : 'text-gray-600'
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? 'fill-blue-600' : ''}`} />
              <span className="text-xs">{tab.label}</span>
            </button>
          );
        })}
      </div>
    );
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'welcome':
        return (
          <WelcomeScreen
            language={language}
            onLanguageChange={handleLanguageChange}
            onStart={() => setCurrentScreen('login')}
          />
        );

      case 'login':
        return (
          <LoginScreen
            language={language}
            onLogin={handleLogin}
            onBack={() => setCurrentScreen('welcome')}
          />
        );

      case 'home':
        if (!user) return null;
        
        if (user.role === 'Worker') {
          return (
            <WorkerHome
              user={user}
              language={language}
              onViewJob={handleViewJob}
              onUpdateUser={handleUpdateUser}
            />
          );
        } else if (user.role === 'Employer') {
          return (
            <EmployerHome
              user={user}
              language={language}
              onPostJob={() => setCurrentScreen('postJob')}
              onViewJob={handleViewJob}
            />
          );
        }
        break;

      case 'jobDetails':
        if (!user) return null;
        return (
          <JobDetails
            jobId={selectedJobId}
            user={user}
            language={language}
            onBack={() => setCurrentScreen('home')}
            onViewProfile={handleViewProfile}
          />
        );

      case 'postJob':
        if (!user) return null;
        return (
          <PostJobForm
            user={user}
            language={language}
            onBack={() => setCurrentScreen('home')}
            onSuccess={() => {
              setCurrentScreen('home');
              setBottomTab('home');
            }}
          />
        );

      case 'myApplications':
        if (!user) return null;
        return (
          <MyApplications
            user={user}
            language={language}
            onViewJob={handleViewJob}
          />
        );

      case 'profile':
        if (!user) return null;
        return (
          <UserProfile
            userId={selectedUserId || user.user_id}
            currentUser={user}
            language={language}
            onBack={() => {
              if (selectedUserId === user.user_id) {
                setCurrentScreen('home');
                setBottomTab('home');
              } else {
                setCurrentScreen('jobDetails');
              }
            }}
          />
        );

      case 'settings':
        if (!user) return null;
        return (
          <Settings
            language={language}
            onLanguageChange={handleLanguageChange}
            onLogout={handleLogout}
          />
        );

      case 'adminDashboard':
        if (!user || user.role !== 'Admin') return null;
        return (
          <AdminDashboard
            language={language}
            onViewUsers={() => setCurrentScreen('adminUsers')}
            onLogout={handleLogout}
          />
        );

      case 'adminUsers':
        if (!user || user.role !== 'Admin') return null;
        return (
          <AdminUsers
            language={language}
            onBack={() => setCurrentScreen('adminDashboard')}
          />
        );

      default:
        return null;
    }
  };

  return (
    <div className="size-full bg-gray-50">
      {renderScreen()}
      {renderBottomNav()}
      <Toaster position="top-center" />
    </div>
  );
}
