# ROZGAAR - Quick Start Guide

## 🚀 Get Started in 3 Steps

### Step 1: Open the App
Simply load the application in your browser.

### Step 2: Access Admin Panel
1. Click **"Get Started"**
2. Click **"Login as Admin (Demo)"** (purple button at bottom)
3. Enter any OTP (e.g., `1234`)
4. You're in! 🎉

### Step 3: Create Demo Data
1. In Admin Dashboard, click **"Seed Demo Data"**
2. Wait for success message
3. Click **"User Management"** to see created users
4. Now you have workers and employers to test with!

---

## 📱 Testing Different Roles

### Test as Admin
**Already done!** You're logged in as admin.

**What to try:**
- View dashboard statistics
- Click "User Management"
- Search for users
- Verify a worker (click Verify button)
- Suspend/activate users
- Logout when done

---

### Test as Worker

1. **Logout** from admin (bottom button)
2. Click **"Get Started"**
3. Select **"Sign Up"**
4. Fill in details:
   - Phone: `9898989898` (any 10-digit number)
   - Name: `Test Worker`
   - Role: **Worker** 👷
   - Skills: Select 2-3 skills (e.g., Mason, Plumber)
5. Click **"Sign Up"**

**What to try:**
- Toggle "Available for Work"
- Browse job feed (if empty, create jobs as employer first)
- Click on a job
- Click "Apply"
- Check "Applications" tab (bottom nav)
- View your profile
- Change language to Hindi
- Logout

---

### Test as Employer

1. **Logout** from worker
2. Click **"Get Started"**
3. Select **"Sign Up"**
4. Fill in details:
   - Phone: `9797979797` (different 10-digit number)
   - Name: `Test Employer`
   - Role: **Employer** 🏢
5. Click **"Sign Up"**

**What to try:**
- Click **"+"** button (bottom right)
- Fill in job details:
  - Title: "Need Plumber"
  - Description: "Fix bathroom tap"
  - Skill: Plumber
  - Budget: 500
- Click "Post Job"
- View applications (if worker applied)
- Click "Accept" on an application
- Click "Mark as Completed"
- Rate the worker (1-5 stars)
- Logout

---

## 🎯 Complete Test Flow

### End-to-End Testing (15 minutes)

1. **Setup (Admin)**
   - Login as admin
   - Seed demo data
   - View created users
   - Logout

2. **Create Job (Employer)**
   - Signup as employer
   - Post a job
   - Note the job details
   - Logout

3. **Apply for Job (Worker)**
   - Signup as worker with matching skill
   - See the job in feed
   - Apply for the job
   - Check "My Applications"
   - Logout

4. **Hire Worker (Employer)**
   - Login as employer (use same phone from step 2)
   - OTP: any 4 digits
   - View job applications
   - Click on worker profile
   - Go back and Accept worker
   - Mark job as completed
   - Rate the worker 5 stars
   - Logout

5. **View Rating (Worker)**
   - Login as worker (use same phone from step 3)
   - OTP: any 4 digits
   - Go to Profile tab
   - See your rating and review!

6. **Manage Users (Admin)**
   - Login as admin
   - Go to User Management
   - Search for worker name
   - Click "Verify" to add verified badge
   - Done! 🎉

---

## 🌟 Quick Tips

### Language Switching
- Click globe icon on welcome screen
- Or go to Settings → Language
- Switch between English and हिंदी anytime

### Demo Data
- **Admin phone**: `9999999999`
- **Demo workers**: Phone starts with `987654`
- **Any OTP works**: Just type 4 digits

### Navigation
- **Bottom tabs**: Quick access to main sections
- **Back buttons**: Return to previous screen
- **Refresh**: Pull down or click refresh buttons

### Troubleshooting
- **No jobs showing?** Make sure you selected matching skills
- **Can't apply?** Toggle "Available for Work" to ON
- **Application disappeared?** It was likely rejected when another worker was accepted

---

## 🎨 What to Look For

### Great UX Elements
✨ Smooth animations
✨ Loading skeletons
✨ Toast notifications
✨ Empty states with helpful messages
✨ Status badges (Open, Assigned, Completed)
✨ Distance display for jobs
✨ Star ratings
✨ Verification badges
✨ Role-based interfaces

### Multilingual Support
🌐 Every screen translated
🌐 Language persists across sessions
🌐 Seamless switching
🌐 Natural Hindi translations

### Smart Features
🎯 Location-based job matching
🎯 Automatic skill filtering
🎯 Distance calculations
🎯 Auto-rejection of other applications when one is accepted
🎯 Availability toggle
🎯 Rating system with reviews

---

## 📊 Test Scenarios

### Scenario 1: Urgent Plumbing Job
```
1. Employer posts "Bathroom tap leaking - urgent!"
2. Worker (plumber) sees it immediately in feed
3. Worker applies with one tap
4. Employer accepts within minutes
5. Job done, both rate each other 5 stars
```

### Scenario 2: Multiple Applications
```
1. Employer posts "Wall painting needed"
2. Three painters apply
3. Employer reviews their profiles and ratings
4. Accepts the highest-rated painter
5. Other two see "Rejected" status
```

### Scenario 3: Admin Moderation
```
1. Admin notices a new worker registration
2. Verifies the worker's credentials
3. Adds verified badge
4. Worker now appears more trustworthy to employers
5. Gets more job opportunities
```

---

## 🎯 Success Indicators

You've successfully tested ROZGAAR when you've:

- ✅ Created users in all 3 roles
- ✅ Posted a job as employer
- ✅ Applied for a job as worker
- ✅ Accepted an application
- ✅ Completed a job
- ✅ Given and received ratings
- ✅ Switched languages
- ✅ Used admin panel to manage users
- ✅ Seeded demo data
- ✅ Verified a worker

---

## 💡 Pro Tips

1. **Use realistic data** - Makes testing more authentic
2. **Try both languages** - See the full i18n implementation
3. **Test on mobile** - Responsive design shines on small screens
4. **Check all tabs** - Each role has different bottom navigation
5. **Read reviews** - View profile pages to see rating system
6. **Suspend a user** - Test admin controls
7. **Apply to multiple jobs** - See application tracking

---

## 🆘 Need Help?

**Can't access admin?**
→ See [ADMIN_GUIDE.md](./ADMIN_GUIDE.md)

**Want full documentation?**
→ See [README.md](./README.md)

**Want to see what's implemented?**
→ See [IMPLEMENTATION_STATUS.md](./IMPLEMENTATION_STATUS.md)

---

## 🎉 Happy Testing!

**Remember**: This is a fully functional demo platform. All data is stored locally in the browser's KV store, so it persists across sessions but is isolated to your browser.

---

*Built with ❤️ for connecting workers and employers*

**Start Now**: Just click "Get Started" and follow Step 1 above! 🚀
