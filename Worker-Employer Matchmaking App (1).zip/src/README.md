# ROZGAAR - Job Matching Platform

**Connecting daily wage workers with local employers in rural and semi-urban areas**

## 🎯 Overview

ROZGAAR is a comprehensive job matching platform that connects daily wage workers (masons, plumbers, electricians, farm laborers) directly with local employers who need temporary labor urgently. The platform eliminates the time and uncertainty workers face when searching for jobs while helping employers find reliable local labor quickly.

## ✨ Key Features

### For Workers
- ✅ **OTP-based Authentication** - Secure mobile login
- 📱 **Job Feed** - View nearby jobs within 5-10 km radius
- 🎯 **Skill Matching** - Jobs filtered by your skills
- 📍 **Location-based** - GPS-based job discovery
- ⭐ **Rating System** - Build reputation through ratings
- 🌐 **Multilingual** - Hindi & English support
- 💼 **Application Tracking** - Monitor your job applications
- 🔔 **Availability Toggle** - Control when you receive notifications

### For Employers
- 📝 **Easy Job Posting** - Quick job creation with details
- 👥 **View Applications** - Review worker profiles and ratings
- ✅ **Accept/Reject** - Choose the right worker for your job
- 💰 **Budget Management** - Set and track job budgets
- 📊 **Job Status Tracking** - Monitor open, assigned, completed jobs
- ⭐ **Rate Workers** - Provide feedback after completion
- 🌐 **Multilingual** - Hindi & English support

### For Admins
- 📊 **Dashboard Overview** - Platform statistics at a glance
- 👥 **User Management** - View, verify, suspend users
- ✅ **Worker Verification** - Verify trusted workers
- 🔍 **Search & Filter** - Find users quickly
- 📈 **Analytics** - Track user and job statistics
- 🗄️ **Demo Data Seeding** - Generate test data easily

## 🚀 Getting Started

### 1. Access the Application
Open the application in your browser

### 2. Choose Your Role

#### As a Worker:
1. Click "Get Started" on welcome screen
2. Select "Sign Up"
3. Enter phone number and name
4. Select role: **Worker**
5. Choose your skills (e.g., Mason, Plumber, Electrician)
6. Complete signup
7. Browse nearby jobs and apply!

#### As an Employer:
1. Click "Get Started" on welcome screen
2. Select "Sign Up"
3. Enter phone number and name
4. Select role: **Employer**
5. Complete signup
6. Post jobs and review applications!

#### As an Admin:
1. Click "Get Started" on welcome screen
2. Click **"Login as Admin (Demo)"** button
3. Enter OTP (any 4 digits like `1234`)
4. Access the Admin Dashboard!

📖 **[Full Admin Guide](./ADMIN_GUIDE.md)**

## 🎨 User Interface

### Navigation
- **Bottom Tab Bar** - Quick access to main sections
  - Home - Job feed or posted jobs
  - Applications (Workers) - Track your applications
  - Profile - View and edit your profile
  - Settings - Language, help, logout

### Language Support
- Switch between **English** and **हिंदी** anytime
- All UI elements fully translated
- Persistent language preference

## 📱 Screens & Features

### Welcome Screen
- App branding and tagline
- Language selector
- Quick start button
- Admin login hint

### Login/Signup Screen
- OTP-based authentication
- Role selection (Worker/Employer)
- Skill selection for workers
- Admin quick access button

### Worker Home
- Availability toggle
- Nearby jobs feed (filtered by skills)
- Distance display for each job
- Quick apply button
- Job details preview

### Employer Home
- Job statistics (Open/Assigned/Completed)
- Posted jobs list
- Quick post job button
- View applications

### Job Details
- Complete job information
- Budget and location
- Skill requirements
- Worker: Apply button
- Employer: Applications list with accept/reject
- Rate after completion

### Post Job Form
- Job title and description
- Skill selection
- Budget input
- Location (auto-filled)
- Date/time picker

### My Applications (Workers)
- All applied jobs
- Application status (Pending/Accepted/Rejected)
- Job details preview
- Quick navigation to job details

### User Profile
- Name and role display
- Verification badge (if verified)
- Average rating and review count
- Skills list (for workers)
- All reviews and ratings
- Location information

### Settings
- User information display
- Language switcher (English/हिंदी)
- Help & Support (placeholder)
- Privacy Policy (placeholder)
- Logout button
- App version info

### Admin Dashboard
- User statistics (Total, Workers, Employers)
- Job statistics (Open, Assigned, Completed)
- Verified workers count and percentage
- Quick actions (User Management, Refresh)
- Seed demo data button
- Logout option

### Admin User Management
- Complete user list
- Search functionality (name/phone)
- Verify workers
- Suspend/activate users
- View user details (role, skills, status)
- Real-time updates

## 🛠️ Technical Stack

### Frontend
- **React** with TypeScript
- **Tailwind CSS** for styling
- **Shadcn/ui** component library
- **Lucide React** for icons
- **Sonner** for toast notifications

### Backend
- **Supabase Functions** (Hono framework)
- **KV Store** for data persistence
- RESTful API architecture
- GPS-based distance calculations (Haversine formula)

### Key Libraries
- `motion/react` for animations
- React hooks for state management
- Local storage for persistence

## 📊 Data Structure

### Users
- user_id, phone, name, role
- location (lat, lng, address)
- skills (for workers)
- rating_avg, rating_count
- status (Active/Suspended)
- verified (boolean)

### Jobs
- job_id, employer_id
- job_title, description
- required_skill, budget
- job_location
- date_posted, job_date
- job_status (Open/Assigned/Completed)

### Applications
- application_id, job_id, worker_id
- status (Pending/Accepted/Rejected)
- created_at

### Ratings
- rating_id, job_id
- from_user_id, to_user_id
- rating (1-5), review
- created_at

## 🔧 Configuration

### Demo Accounts

**Admin Account:**
- Phone: `9999999999`
- Role: Admin (auto-assigned)
- Verification: Auto-verified

**Demo Workers & Employers:**
- Created via "Seed Demo Data" button
- Phone numbers: `987654xxxx`
- Various skills and locations

## 🌟 Demo Features

### Location-Based Matching
- Jobs within 5-10 km radius
- Distance calculated using Haversine formula
- Sorted by proximity

### Real-time Updates
- Instant application notifications
- Job status changes
- Rating updates

### Mutual Rating System
- Workers rate employers
- Employers rate workers
- Average rating calculation
- Review system

## 📝 API Endpoints

### Authentication
- `POST /signup` - Create new user
- `POST /signin` - Login with OTP

### Users
- `GET /user/:userId` - Get user details
- `PUT /user/:userId` - Update user

### Jobs
- `POST /jobs` - Create job
- `GET /jobs/worker/:workerId` - Get nearby jobs
- `GET /jobs/employer/:employerId` - Get employer's jobs
- `GET /jobs/:jobId` - Get job details
- `PUT /jobs/:jobId` - Update job
- `DELETE /jobs/:jobId` - Delete job

### Applications
- `POST /applications` - Apply for job
- `GET /applications/job/:jobId` - Get job applications
- `GET /applications/worker/:workerId` - Get worker applications
- `PUT /applications/:appId` - Update application status

### Ratings
- `POST /ratings` - Submit rating
- `GET /ratings/:userId` - Get user ratings

### Admin
- `GET /admin/users` - Get all users
- `GET /admin/jobs` - Get all jobs
- `GET /admin/stats` - Get platform statistics
- `PUT /admin/users/:userId` - Update user status

## 🎯 Use Cases

### Scenario 1: Worker Finding Job
1. Worker opens app and toggles "Available for Work"
2. Browses nearby jobs matching their skills
3. Applies to interesting jobs
4. Gets accepted by employer
5. Completes job
6. Receives rating from employer

### Scenario 2: Employer Posting Job
1. Employer needs a plumber urgently
2. Posts job with details and budget
3. Receives applications from nearby plumbers
4. Reviews ratings and skills
5. Accepts suitable worker
6. Marks job complete after work
7. Rates the worker

### Scenario 3: Admin Management
1. Admin logs in
2. Views platform statistics
3. Seeds demo data for testing
4. Verifies new worker accounts
5. Suspends problematic users
6. Monitors job completion rates

## 🔐 Security Notes

⚠️ **This is a demo/prototype implementation**

For production deployment, implement:
- Real OTP verification (SMS gateway)
- Proper authentication tokens
- Row-level security
- Rate limiting
- Input validation and sanitization
- HTTPS enforcement
- Data encryption
- Payment gateway integration
- Compliance with data protection laws (GDPR, etc.)

## 🚧 Future Enhancements

- [ ] In-app chat between workers and employers
- [ ] Payment integration
- [ ] Photo upload for jobs and profiles
- [ ] Advanced filtering (budget range, date range)
- [ ] Push notifications
- [ ] Worker verification with ID documents
- [ ] Emergency contact system
- [ ] Job history and analytics
- [ ] Referral system
- [ ] Multiple language support (regional languages)
- [ ] Offline mode support
- [ ] Dark mode

## 📱 Mobile Optimization

The application is fully responsive and optimized for:
- Mobile devices (primary target)
- Tablets
- Desktop browsers

Touch-friendly interface with:
- Large tap targets
- Smooth scrolling
- Pull-to-refresh (where applicable)
- Bottom navigation for easy thumb access

## 🐛 Troubleshooting

### Common Issues

**Can't login:**
- Ensure phone number is 10 digits
- OTP can be any 4 digits (demo mode)
- Clear browser cache

**No jobs showing:**
- Check if skills are selected (workers)
- Ensure location permissions (if implemented)
- Try toggling availability

**Admin panel not accessible:**
- Use phone: `9999999999`
- Click "Login as Admin (Demo)" button
- See [ADMIN_GUIDE.md](./ADMIN_GUIDE.md)

## 📄 License

This is a demo project created for portfolio/learning purposes.

## 🤝 Contributing

This is a prototype application. For production use, significant security and feature enhancements are required.

## 📞 Support

For questions or issues, please refer to the documentation or create an issue in the repository.

---

**Built with ❤️ for connecting workers and employers**

*Rural & Semi-Urban Focus • Lightweight • Multilingual • Accessible*
