import { api } from './api';

// Seed demo data for testing the admin panel
export async function seedDemoData() {
  try {
    console.log('Seeding demo data...');

    // Create demo workers
    const workers = [
      {
        phone: '9876543210',
        name: 'Ravi Kumar',
        role: 'Worker',
        location: { lat: 28.6139, lng: 77.2090, address: 'Sector 15, Noida' },
        skills: ['mason', 'painter']
      },
      {
        phone: '9876543211',
        name: 'Suresh Sharma',
        role: 'Worker',
        location: { lat: 28.6200, lng: 77.2100, address: 'Sector 18, Noida' },
        skills: ['plumber', 'electrician']
      },
      {
        phone: '9876543212',
        name: 'Amit Singh',
        role: 'Worker',
        location: { lat: 28.6150, lng: 77.2050, address: 'Sector 12, Noida' },
        skills: ['carpenter', 'generalLabor']
      }
    ];

    // Create demo employers
    const employers = [
      {
        phone: '9876543220',
        name: 'Rajesh Verma',
        role: 'Employer',
        location: { lat: 28.6139, lng: 77.2090, address: 'Sector 16, Noida' }
      },
      {
        phone: '9876543221',
        name: 'Priya Gupta',
        role: 'Employer',
        location: { lat: 28.6180, lng: 77.2080, address: 'Sector 19, Noida' }
      }
    ];

    // Sign up workers
    for (const worker of workers) {
      try {
        await api.signup(worker);
        console.log(`Created worker: ${worker.name}`);
      } catch (error) {
        console.log(`Worker ${worker.name} might already exist`);
      }
    }

    // Sign up employers
    for (const employer of employers) {
      try {
        await api.signup(employer);
        console.log(`Created employer: ${employer.name}`);
      } catch (error) {
        console.log(`Employer ${employer.name} might already exist`);
      }
    }

    console.log('Demo data seeded successfully!');
    return true;
  } catch (error) {
    console.error('Error seeding demo data:', error);
    return false;
  }
}
