import { projectId, publicAnonKey } from './supabase/info';

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-e49dcc0e`;

export const api = {
  // Auth
  async signup(data: { phone: string; name: string; role: string; location?: any; skills?: string[] }) {
    const response = await fetch(`${API_BASE}/signup`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${publicAnonKey}`,
      },
      body: JSON.stringify(data),
    });
    return response.json();
  },

  async signin(phone: string, otp: string) {
    const response = await fetch(`${API_BASE}/signin`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${publicAnonKey}`,
      },
      body: JSON.stringify({ phone, otp }),
    });
    return response.json();
  },

  // Users
  async getUser(userId: string) {
    const response = await fetch(`${API_BASE}/user/${userId}`, {
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
      },
    });
    return response.json();
  },

  async updateUser(userId: string, updates: any) {
    const response = await fetch(`${API_BASE}/user/${userId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${publicAnonKey}`,
      },
      body: JSON.stringify(updates),
    });
    return response.json();
  },

  // Jobs
  async postJob(jobData: any) {
    const response = await fetch(`${API_BASE}/jobs`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${publicAnonKey}`,
      },
      body: JSON.stringify(jobData),
    });
    return response.json();
  },

  async getJobsForWorker(workerId: string, radius: number = 10) {
    const response = await fetch(`${API_BASE}/jobs/worker/${workerId}?radius=${radius}`, {
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
      },
    });
    return response.json();
  },

  async getJobsForEmployer(employerId: string) {
    const response = await fetch(`${API_BASE}/jobs/employer/${employerId}`, {
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
      },
    });
    return response.json();
  },

  async getJob(jobId: string) {
    const response = await fetch(`${API_BASE}/jobs/${jobId}`, {
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
      },
    });
    return response.json();
  },

  async updateJob(jobId: string, updates: any) {
    const response = await fetch(`${API_BASE}/jobs/${jobId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${publicAnonKey}`,
      },
      body: JSON.stringify(updates),
    });
    return response.json();
  },

  async deleteJob(jobId: string) {
    const response = await fetch(`${API_BASE}/jobs/${jobId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
      },
    });
    return response.json();
  },

  // Applications
  async applyForJob(jobId: string, workerId: string) {
    const response = await fetch(`${API_BASE}/applications`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${publicAnonKey}`,
      },
      body: JSON.stringify({ job_id: jobId, worker_id: workerId }),
    });
    return response.json();
  },

  async getApplicationsForJob(jobId: string) {
    const response = await fetch(`${API_BASE}/applications/job/${jobId}`, {
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
      },
    });
    return response.json();
  },

  async getApplicationsForWorker(workerId: string) {
    const response = await fetch(`${API_BASE}/applications/worker/${workerId}`, {
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
      },
    });
    return response.json();
  },

  async updateApplication(appId: string, status: string, employerId: string) {
    const response = await fetch(`${API_BASE}/applications/${appId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${publicAnonKey}`,
      },
      body: JSON.stringify({ status, employer_id: employerId }),
    });
    return response.json();
  },

  // Ratings
  async submitRating(data: { job_id: string; from_user_id: string; to_user_id: string; rating: number; review?: string }) {
    const response = await fetch(`${API_BASE}/ratings`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${publicAnonKey}`,
      },
      body: JSON.stringify(data),
    });
    return response.json();
  },

  async getRatings(userId: string) {
    const response = await fetch(`${API_BASE}/ratings/${userId}`, {
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
      },
    });
    return response.json();
  },

  // Admin
  async getAllUsers() {
    const response = await fetch(`${API_BASE}/admin/users`, {
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
      },
    });
    return response.json();
  },

  async getAllJobs() {
    const response = await fetch(`${API_BASE}/admin/jobs`, {
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
      },
    });
    return response.json();
  },

  async getAdminStats() {
    const response = await fetch(`${API_BASE}/admin/stats`, {
      headers: {
        'Authorization': `Bearer ${publicAnonKey}`,
      },
    });
    return response.json();
  },

  async updateUserStatus(userId: string, updates: any) {
    const response = await fetch(`${API_BASE}/admin/users/${userId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${publicAnonKey}`,
      },
      body: JSON.stringify(updates),
    });
    return response.json();
  },
};
