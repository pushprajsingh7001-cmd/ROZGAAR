
  # Worker-Employer Matchmaking App

  This is a code bundle for Worker-Employer Matchmaking App. The original project is available at https://www.figma.com/design/dpK1YTbYns64QBXUwNda71/Worker-Employer-Matchmaking-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  